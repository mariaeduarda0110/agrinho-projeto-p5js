function setup() {
  createCanvas(400, 400);
}

function draw() {
  background("brown");
}

let cenouras = [];
let qtdColhidas = 0;
let raio = 30; // Raio das cenouras

function setup() {
  createCanvas(600, 400);
  // Criando cenouras aleatórias
  for (let i = 0; i < 10; i++) {
    let cenoura = {
      x: random(width),
      y: random(height),
      coletada: false
    };
    cenouras.push(cenoura);
  }
}

function draw() {
  background(220);

  // Desenhando as cenouras
  for (let i = 0; i < cenouras.length; i++) {
    if (!cenouras[i].coletada) {
      fill(255, 100, 0); // cor da cenoura
      noStroke();
      ellipse(cenouras[i].x, cenouras[i].y, raio * 2);
    }
  }

  // Desenhando a quantidade de cenouras colhidas
  fill(0);
  textSize(24);
  text(`Cenouras colhidas: ${qtdColhidas}`, 20, 30);
}

function mousePressed() {
  // Verificando se o mouse clicou em alguma cenoura
  for (let i = 0; i < cenouras.length; i++) {
    let d = dist(mouseX, mouseY, cenouras[i].x, cenouras[i].y);
    if (d < raio && !cenouras[i].coletada) {
      cenouras[i].coletada = true;
      qtdColhidas++;
    }
  }
}

